//
//  main.swift
//  NSThread
//
//  Created by Dan Beaulieu on 12/19/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation


class Threading: NSObject {
    
    var val = 0
    var lock = NSLock()
    
    func riseFall() {
        
        (0...5000).forEach { _ in
            lock.lock()
            let v = val + 1
            print(v)
            val = v
            lock.unlock()

        }
        
        (0...5000).forEach { _ in
            lock.lock()
            let v = val - 1
            print(v)
            val = v
            lock.unlock()
        }
    }
    
}

let count = Threading()

NSThread.detachNewThreadSelector("riseFall", toTarget: count, withObject: nil)
count.riseFall()

sleep(1)