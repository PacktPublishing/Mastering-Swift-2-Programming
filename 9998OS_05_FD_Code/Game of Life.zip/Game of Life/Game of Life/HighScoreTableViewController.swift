//
//  HighScoreTableViewController.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 12/20/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import UIKit

class HighScoreTableViewController: UITableViewController {

    @IBOutlet weak var menuButton: UIBarButtonItem!
    var indicator = UIActivityIndicatorView()

    var scores = [Score]() {
        didSet {
           let mainQueue = NSOperationQueue.mainQueue()
           mainQueue.addOperationWithBlock() {
                self.tableView.reloadData()
           }
            
        }
    
    }
    
    func getScores() {
    
        self.indicator.startAnimating()
        self.indicator.backgroundColor = UIColor.whiteColor()
    

        Connect().getAllScores { (result) -> () in
            
                let scoreData = result as! [AnyObject]
            
                scoreData.forEach { item in
                    self.scores.append(Score(name: item["UserName"] as! String, score: item["Moves"] as! Int))
              }
        
       
            self.indicator.stopAnimating()
            self.indicator.hidesWhenStopped = true
        }
            
    } 
        
    func activityIndicator() {
        indicator = UIActivityIndicatorView(frame: CGRectMake(0, 0, 40, 40))
        indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        indicator.center = self.view.center
        self.view.addSubview(indicator)
    }
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
            self.getScores()

            if self.revealViewController() != nil {
         
                self.menuButton.target = self.revealViewController()
                self.menuButton.action = "revealToggle:"
                self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
                
                // Uncomment to change the width of menu
                self.revealViewController().rearViewRevealWidth = 200
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return (scores.count) ?? 0
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("scoreCell", forIndexPath: indexPath)

        cell.textLabel!.text = scores[indexPath.row].name
        cell.detailTextLabel!.text = "\(scores[indexPath.row].score)"
        return cell
    }


   
}
