//
//  Game_of_LifeTests.swift
//  Game of LifeTests
//
//  Created by Dan Beaulieu on 11/25/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import XCTest
@testable import Game_of_Life

class Game_of_LifeTests: XCTestCase {
    
    let life = Life()
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        


        
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testInitializeGame() {
        func initializeGame() {
            // randomize cell states on grid
            for cell in self.life.cells {
                cell.state = State(rawValue: Int(arc4random_uniform(2)))!
                
            }
            
        }
        func initializeGameB() {
            // randomize cell states on grid
            self.life.cells = self.life.cells.map {
                $0.state = State(rawValue: Int(arc4random_uniform(2)))!
                return $0
            }
            
        }
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
            initializeGame()
        }
        
        
    }
    
    func testEvolve() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
            self.life.evolve()
        }
        
        
    }
    
}
