//
//  Connect.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 12/20/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation
import Alamofire


class Connect {

    
    static func postNewScore() {
        let parameters = [
            "Moves": 25500,
            "UserName" : "Lifes Bot"
        ]
        
        Alamofire.request(.POST, "https://danbeaulieu.azurewebsites.net/postscore", parameters: parameters, encoding: .JSON).responseString { response in
            print("Response String: \(response.result.value)")
        }
    }

    func getAllScores(completion: (result: AnyObject) -> ()) {
   
        Alamofire.request(.GET, "https://danbeaulieu.azurewebsites.net/api/scores", parameters: nil)
            .responseJSON { response in
                
                print("status \(response.response)")
                
                if let JSON = response.result.value {
                    print(JSON)
                    completion(result: JSON)
                }
        }
    }
}