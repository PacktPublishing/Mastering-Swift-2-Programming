//
//  Cell.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation

class Cell {
    let xCoord: Int
    let yCoord: Int
    var state : State
    
    init(x: Int, y: Int) {
        self.xCoord = x
        self.yCoord = y
        state = .PreBirth
    }
}