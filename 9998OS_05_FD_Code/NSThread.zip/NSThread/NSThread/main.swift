//
//  main.swift
//  NSThread
//
//  Created by Dan Beaulieu on 12/19/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation


class Threading: NSObject {
    
    var val = 0
    
    func riseFall() {
        
        (0...5000).forEach { _ in
            let v = val + 1
            print(v)
            val = v

        }
        
        (0...5000).forEach { _ in
            let v = val - 1
            print(v)
            val = v
   
        }
    }
}

let count = Threading()

NSThread.detachNewThreadSelector("riseFall", toTarget: count, withObject: nil)

count.riseFall()


sleep(1)