//
//  ViewController.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    var life = Life()
    let gameBoard : GameBoard
    var timer : NSTimer!
    var running = false
    var steps = 0
    
    @IBOutlet weak var menuButton: UIBarButtonItem!
    @IBOutlet weak var boardView: UIView!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var cellCountLabel: UILabel!
    
    @IBAction func handleResetTapped(sender: UIButton) {
        if running == true {
            endGame()
        } else {
            resetButton.titleLabel!.text = "Stop"
        }
        
    }
    
    func startTimer(recognizer: UIGestureRecognizer) {
        timer = NSTimer.scheduledTimerWithTimeInterval(0.05, target: self, selector: "moment", userInfo: nil, repeats: true)
        resetButton.enabled = true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        gameBoard = GameBoard(createLife: life)
        
        super.init(coder: aDecoder)
        initializeGame()
    }
    
    convenience init(){
        self.init()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Connect.postNewScore()
        
        let color = UIColor(red: 55/255, green: 55/255, blue: 55/255, alpha: 1.0)
        boardView.backgroundColor = UIColor.whiteColor()
        view.backgroundColor = color
        
        gameBoard.frame = boardView.frame
        gameBoard.center = CGPointMake(gameBoard.frame.size.width / 2, gameBoard.frame.size.height / 2)
        boardView.addSubview(gameBoard)
        
        let tap = UITapGestureRecognizer(target: self, action: "startTimer:")
        boardView.addGestureRecognizer(tap)
        
        if self.revealViewController() != nil {
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
            // Uncomment to change the width of menu
            self.revealViewController().rearViewRevealWidth = 200
        }
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "passCount:", name: "passCountId", object: nil)
        
    }
    
    func initializeGame() {
        life.cells.forEach { $0.state = State(rawValue: Int(arc4random_uniform(2)))! }
    }

    
    func endGame() {
        steps = 0
        timer.invalidate()
        resetButton.titleLabel!.text = "Reset"
        resetButton.enabled = false
        running = false
        initializeGame()
        showAlert()
        
    }
    

    func passCount(notification: NSNotification) {
        guard let count = notification.object else {
            return
        }
        
        if (count as! Int) > 30 {
            steps = steps + 1
            cellCountLabel.text = "\(count)"
        } else {
            endGame()
        }
        
    }
    
    func configurationTextField(textField: UITextField!)
    {

    }
    
    func showAlert() {
        
        let alert = UIAlertController(title: "\(self.steps) iterations", message: "Feel free to enter your desired name and press 'post' to add your score to the leaderboard.", preferredStyle: UIAlertControllerStyle.Alert)
        
        alert.addTextFieldWithConfigurationHandler(configurationTextField)
        
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler:{ (UIAlertAction) in
            
        }))
        
        self.presentViewController(alert, animated: true, completion: {
            
        })
    
    }
    
    func moment() {
        
        if running == false {
            self.resetButton.titleLabel!.text = "Stop"
            running = true
        }
        
        life.evolve { (remaining) -> () in
            let cellsLeft = remaining
            print(cellsLeft)
            self.endGame()
        }
        
        
        
        
        gameBoard.setNeedsDisplay() // instructs a redraw
    
    }
}

