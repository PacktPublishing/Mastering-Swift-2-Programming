//
//  Life.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation

class Life {

    var cells: [Cell]
    let gridSize: Int = 20

    init() {
        cells = [Cell]() // initialize our cells
        cells = assignCellsToGrid()
    }
    
    lazy var assignCellsToGrid: () -> [Cell] = {
        [weak self] in
        var cells = [Cell]()
        for xLoc in 0..<self!.gridSize {
            for yLoc in 0..<self!.gridSize {
                cells.append(Cell(x: xLoc, y: yLoc))
                
            }
        }
        return cells
    }
    
    func evolve(completion: (remaining: Int) -> ()) {
        
        let liveCells = cells.filter { $0.state == State.Living }
        let deadCells = cells.filter { $0.state != State.Living }
        
        // Rules 1,2, & 3
        let dyingCells = liveCells.filter { !(2...3 ~= livingNeighbors($0)) }
        
        // Rule 4
        let newLife = deadCells.filter { livingNeighbors($0) == 3 }
        
        newLife.forEach { $0.state = .Living }
        dyingCells.forEach { $0.state = .Dead }
        
        if (liveCells.count < 40) {
            completion(remaining: liveCells.count)
        }
        
        
        NSNotificationCenter.defaultCenter().postNotificationName("passCountId", object: liveCells.count)
        
    }
    
    
    func cellsAreNeighbors(sideA: Cell, sideB: Cell) -> Bool {
        let split = (abs(sideA.xCoord - sideB.xCoord), abs(sideA.yCoord - sideB.yCoord))
        
        switch split {
        case (1,1), (1,0), (0,1):
            return true
        default:
            return false
        }
    }
    
    func cellNeighbors(cell: Cell) -> [Cell] {
        // our re-implementation of Swift's .filter function
        return self.cells.filterNeighbors { self.cellsAreNeighbors(cell, sideB: $0) }
    }
    
    func livingNeighbors(cell: Cell) -> Int {
        return cellNeighbors(cell).filter {$0.state == State.Living }.count
    }

}


