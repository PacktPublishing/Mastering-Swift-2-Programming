//
//  Utility.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/28/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation


extension Array {
    func filterNeighbors(predicate: Element -> Bool) -> [Element] {
        var filteredArray = [Element]()
        for x in self where predicate(x) {
            filteredArray.append(x)
        }
        
        return filteredArray
    }
}

extension Array {
    func mapCells(transform: (Element) -> Element) -> [Element] {
        var result: [Element] = []
        for item in self {
            result.append(transform(item))
        }
        return result
    }
}