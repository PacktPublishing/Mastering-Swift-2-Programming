//
//  main.swift
//  ObjectiveCInSwift
//
//  Created by Dan Beaulieu on 12/11/15.
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation



var fibs = RandomFibs(fibQty: 5)

for f in fibs {
    print("fibonacci random fib: \(f)")
}