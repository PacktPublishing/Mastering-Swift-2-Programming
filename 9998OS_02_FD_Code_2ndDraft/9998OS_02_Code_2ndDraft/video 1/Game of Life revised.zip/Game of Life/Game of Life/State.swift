//
//  State.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation

enum State : Int {
    case Living = 0, PreBirth, Dead
    
    static func randomState() -> State {
        
        guard let state = State(rawValue: Int(arc4random_uniform(2))) else {
            return .PreBirth
        }
        
        return state
    }
}

