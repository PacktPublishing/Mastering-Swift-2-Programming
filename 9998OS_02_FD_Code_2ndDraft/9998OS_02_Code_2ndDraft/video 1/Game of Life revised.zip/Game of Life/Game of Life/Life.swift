//
//  Life.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import Foundation

class Life {

    var cells: [Cell]
    let gridSize: Int = 20
    
    init() {
        cells = [Cell]()
        for xLoc in 0..<self.gridSize {
            for yLoc in 0..<self.gridSize {
                cells.append(Cell(x: xLoc, y: yLoc))
                
            }
        }
    }
    
}