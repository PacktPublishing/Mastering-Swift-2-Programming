//
//  ViewController.swift
//  Game of Life
//
//  Created by Dan Beaulieu on 11/25/15.
//  Inspired by John Conway, Colin Eberhardt
//  Copyright © 2015 Dan Beaulieu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var life = Life()
    let gameBoard : GameBoard
    var timer : NSTimer!
    
    @IBOutlet weak var boardView: UIView!
    
    required init?(coder aDecoder: NSCoder) {
        gameBoard = GameBoard(createLife: life)
        
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        gameBoard.frame = boardView.frame
        gameBoard.center = CGPointMake(gameBoard.frame.size.width / 2, gameBoard.frame.size.height / 2)
        boardView.addSubview(gameBoard)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

